from util import get_word_count, window_slide
from pathlib import Path
from collections import OrderedDict
import os
import re
import json
import math


# get N for each count
def get_N(b_counts):
    bigram_N = OrderedDict()
    for key, value in b_counts.items():

        if value not in bigram_N:
            bigram_N[value] = 1
        else:
            bigram_N[value] = bigram_N[value] + 1
    return bigram_N


def train_model(b_counts):
    n_prob_dict = dict()

    bigram_N = get_N(b_counts)
    n = 0
    for key, val in bigram_N.items():
        n = n + key * val
    n_prob_dict[0] = bigram_N[1] / n
    # print(sorted(bigram_N.items()))
    for key, val in bigram_N.items():
        if key + 1 in bigram_N:
            c = (key + 1) * bigram_N[key + 1] / val
        else:
            c = (key + 1) * 1 / val

        n_prob_dict[key] = c / n
    return n_prob_dict


def get_model():
    _, b_counts = get_word_count()
    model = Path("model/")
    model_path = model / "bigram_with_good_turing_smoothing.json"

    if os.path.isfile(model_path):
        with open(model_path) as f:
            n_prob_dict = json.load(f)
    else:
        n_prob_dict = train_model(b_counts)
        with open(model_path, "w") as f:
            json.dump(n_prob_dict, f)
    return n_prob_dict


def predict(word):
    n_prob_dict = get_model()
    _, b_counts = get_word_count()
    max_p = 0
    p_word = ""
    for key, val in b_counts.items():
        words = re.split(r"\s", key)
        if words[0] == word:
            t = max(max_p, n_prob_dict[str(val)])
            if t != max_p:
                max_p = t
                p_word = words[1]
    return p_word


def possibility_given_slide(slide, n_prob_dict=get_model()):
    n_counts, b_counts = get_word_count()
    words = re.split(r"\s", slide)
    if words[0] not in n_counts:
        words[0] = "<unk>"
    if words[1] not in n_counts:
        words[1] = "<unk>"
    slide = ' '.join(map(str, words))
    if slide not in b_counts:
        key = '0'
    else:
        key = b_counts[slide]
    return n_prob_dict[str(key)]


def get_perplexity_score(line):
    prob_dict = get_model()
    slides = window_slide(line, 2)
    n = len(slides)
    perplexity_score = 1
    for slide in slides:
        perplexity_score = perplexity_score * 1 / possibility_given_slide(slide, prob_dict)
    return pow(perplexity_score, 1 / n)

# from collections import OrderedDict
# d = {int(k):float(v) for k,v in get_model().items()}
# test = sorted(d.items())
# print(test)
