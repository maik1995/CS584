from util import get_word_count, window_slide
from pathlib import Path
import operator
import os
import re
import json


def train_model(u_counts, b_counts):
    prob_dict = dict()
    for b_w, b_c in b_counts.items():
        word = re.split(r"\s", b_w)
        u_w = word[0]
        p_w = word[1]
        u_c = u_counts[u_w]
        if u_w not in prob_dict:
            prob_dict[u_w] = {}
        prob_dict[u_w][p_w] = b_c / u_c
    return prob_dict


def get_model():
    model = Path("model/")
    model_path = model / "raw_bigram.json"

    u_counts, b_counts = get_word_count()

    if os.path.isfile(model_path):
        with open(model_path) as f:
            prob_dict = json.load(f)
    else:
        prob_dict = train_model(u_counts, b_counts)
        with open(model_path, "w") as f:
            json.dump(prob_dict, f)
    # return probability dictionary
    return prob_dict


def predict(word):
    prob_dict = get_model()
    if word not in prob_dict:
        word = "<unk>"
    res = prob_dict[word]
    return max(res.items(), key=operator.itemgetter(1))[0]


def possibility_given_slide(slide, prob_dict=get_model()):
    words = re.split(r"\s", slide)
    if words[0] not in prob_dict:
        words[0] = "<unk>"
    if words[1] not in prob_dict[words[0]]:
        words[1] = "<unk>"
    if words[1] not in prob_dict[words[0]]:
        return 1e-20
    return prob_dict[words[0]][words[1]]


def get_perplexity_score(line):
    prob_dict = get_model()
    slides = window_slide(line, 2)
    n = len(slides)
    perplexity_score = 1
    for slide in slides:
        perplexity_score = perplexity_score * 1 / possibility_given_slide(slide, prob_dict)
    return pow(perplexity_score, 1 / n)
