from util import get_word_count, window_slide
from pathlib import Path
import os
import re
import json
import operator

processed_data_root = Path("processed_data/")
preceded_count_path = processed_data_root / "preceded_count.json"
following_count_path = processed_data_root / "following_count.json"

if os.path.isfile(preceded_count_path):
    with open(preceded_count_path) as f:
        preceded_count_dict = json.load(f)
else:
    preceded_count_dict = dict()

if os.path.isfile(following_count_path):
    with open(following_count_path) as f:
        following_count_dict = json.load(f)
else:
    following_count_dict = dict()


# get {w:C(Wi-1, w)>0}
def get_following_count(b_count, word):
    count = 0
    if word in following_count_dict:
        return following_count_dict[word]
    for key, val in b_count.items():
        words = re.split(r"\s", key)
        if words[0] == word:
            count = count + 1
    following_count_dict[word] = count
    return count


# get {wi-1:C(Wi-1, w)>0}
def get_preceded_count(b_count, word):
    count = 0
    if word in preceded_count_dict:
        return preceded_count_dict[word]
    for key, val in b_count.items():
        words = re.split(r"\s", key)
        if words[1] == word:
            count = count + 1
    preceded_count_dict[word] = count
    return count


def train_model(u_count, b_count):
    prob_dict = dict()
    total_entries = len(b_count)
    d = 0.75
    step = 0
    for key, val in b_count.items():
        words = re.split(r"\s", key)
        count_i_0 = u_count[words[0]]
        preceded_count = get_preceded_count(b_count, words[1])
        following_count = get_following_count(b_count, words[0])

        lam = d * following_count / count_i_0
        p_continuation = preceded_count / total_entries
        first_term = max(val - d, 0) / count_i_0
        if words[0] not in prob_dict:
            prob_dict[words[0]] = dict()
        prob_dict[words[0]][words[1]] = first_term + lam * p_continuation
        step = step + 1
        print(step / total_entries)
    return prob_dict


def get_model():
    model = Path("model/")
    model_path = model / "bigram_with_Kneser_Ney_smoothing.json"

    u_counts, b_counts = get_word_count()

    if os.path.isfile(model_path):
        with open(model_path) as f:
            prob_dict = json.load(f)
    else:
        prob_dict = train_model(u_counts, b_counts)
        with open(model_path, "w") as f:
            json.dump(prob_dict, f)
        with open(preceded_count_path, "w") as f:
            json.dump(preceded_count_dict, f)
        with open(following_count_path, "w") as f:
            json.dump(following_count_dict, f)
    # return probability dictionary
    return prob_dict


def predict(word):
    prob_dict = get_model()
    if word not in prob_dict:
        word = "<unk>"
    res = prob_dict[word]
    return max(res.items(), key=operator.itemgetter(1))[0]


def possibility_given_slide(slide, prob_dict=get_model()):
    u_counts, b_counts = get_word_count()
    words = re.split(r"\s", slide)
    d = 0.75

    total_entries = len(b_counts)

    if words[0] not in u_counts:
        words[0] = "<unk>"
    if words[1] not in u_counts:
        words[1] = "<unk>"
    if words[0] not in prob_dict:
        count_i_0 = u_counts[words[0]]

        preceded_count = get_preceded_count(b_counts, words[1])
        following_count = get_following_count(b_counts, words[0])

        lam = d * following_count / count_i_0
        p_continuation = preceded_count / total_entries
        return lam * p_continuation
    if words[1] not in prob_dict[words[0]]:
        count_i_0 = u_counts[words[0]]

        preceded_count = get_preceded_count(b_counts, words[1])
        following_count = get_following_count(b_counts, words[0])

        lam = d * following_count / count_i_0
        p_continuation = preceded_count / total_entries
        return lam * p_continuation
    return prob_dict[words[0]][words[1]]


def get_perplexity_score(line):
    prob_dict = get_model()
    slides = window_slide(line, 2)
    n = len(slides)
    perplexity_score = 1
    for slide in slides:
        perplexity_score = perplexity_score * 1 / possibility_given_slide(slide, prob_dict)
    return pow(perplexity_score, 1 / n)
