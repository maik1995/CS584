import numpy as np
import tensorflow as tf
import re
from util import get_word_dict
from pathlib import Path

data_root = Path("a3-data/")


def transform_sentence(sentence, word_dict):
    words = re.split(r"\s", sentence)
    for i in range(len(words)):
        words[i] = word_dict[words[i].lower()]
    return words


def rnn_model(batchsize, input_length, units, dict_size):
    inputs = tf.keras.Input(shape=input_length, batch_size=batchsize, dtype="int32")
    # print(inputs.shape)
    embedding_layer_output = tf.keras.layers.Embedding(input_dim=dict_size, output_dim=10, input_length=input_length)(
        inputs)
    lstm_layer_seq_output = tf.keras.layers.LSTM(units=units, return_sequences=True,
                                                 dropout=1e-3)(embedding_layer_output)
    dense_layer_output = tf.keras.layers.Dense(units=dict_size)(lstm_layer_seq_output)
    softmax_output = tf.keras.layers.Softmax()(dense_layer_output)
    # print(lstm_layer_seq_output.shape)
    model = tf.keras.Model(inputs=inputs, outputs=softmax_output)
    return model


def preprocess_train_data(window_size):
    word_dict, _ = get_word_dict()
    train_path = data_root / "train.txt"
    train_x = list()
    train_y = list()
    with open(train_path) as f:
        for line in f.readlines():
            words = transform_sentence(line, word_dict)
            if len(words) <= window_size:
                fill = word_dict['']
                for i in range(len(words), window_size):
                    words.append(fill)
            print(len(words))
            train_x.append(words[0:-1])
            train_y.append(words[1:])


model = rnn_model(50, 20, 128, 10000)
model.summary()
