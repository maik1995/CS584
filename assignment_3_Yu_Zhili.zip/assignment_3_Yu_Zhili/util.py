from pathlib import Path
import os
import re
import json

# from gensim import utils
# from gensim.models import Word2Vec
# from gensim.test.utils import datapath

data_root = Path("a3-data/")
processed_data_root = Path("processed_data/")


def get_test_path():
    test_path = data_root / "valid.txt"
    return test_path


# slide window function
def window_slide(text, s):
    slides = list()
    word_list = re.split(r"\s", text)
    for i in range(len(word_list) - s + 1):
        words = " ".join([str(word) for word in word_list[i:i + s]])
        slides.append(words)
    return slides


# get the count for combination of two words.
def create_bigram_word_count():
    word_count = dict()
    train_path = data_root / "train.txt"
    index = 0
    with open(train_path, "r") as train_f:
        for line in train_f.readlines():
            slide = window_slide(line, 2)
            for word in slide:
                word = word.lower()
                if word not in word_count:
                    word_count[word] = 1
                else:
                    word_count[word] = word_count[word] + 1

    return word_count


# get the count for one word
def create_unigram_word_count():
    word_count = dict()
    train_path = data_root / "train.txt"
    index = 0
    with open(train_path, "r") as train_f:
        for line in train_f.readlines():
            for word in re.split(r"\s", line):
                word = word.lower()
                if word not in word_count:
                    word_count[word] = 1
                else:
                    word_count[word] = word_count[word] + 1
    return word_count


# function used to get word count
def get_word_count():
    unigram_count_path = processed_data_root / "unigram_word_count.json"
    bigram_count_path = processed_data_root / "bigram_word_count.json"

    if os.path.isfile(unigram_count_path) and os.path.isfile(bigram_count_path):
        with open(unigram_count_path) as f:
            unigram_word_count = json.load(f)
        with open(bigram_count_path) as f:
            bigram_word_count = json.load(f)
        return unigram_word_count, bigram_word_count

    unigram_word_count = create_unigram_word_count()
    bigram_word_count = create_bigram_word_count()
    # save the count to local so that we don't need to do it again
    with open(unigram_count_path, "w") as f:
        json.dump(unigram_word_count, f)
    with open(bigram_count_path, "w") as f:
        json.dump(bigram_word_count, f)
    return unigram_word_count, bigram_word_count


# class MyCorpus(object):
#     """An interator that yields sentences (lists of str)."""
#
#     def __iter__(self):
#         train_path = data_root / "train.txt"
#         for line in open(train_path):
#             # assume there's one document per line, tokens separated by whitespace
#             yield utils.simple_preprocess(line)
#
#
# def get_word2vec_model():
#     if os.path.exists("word2vec.npy"):
#         model = Word2Vec.load("word2vec.npy")
#         return model
#
#     sentences = MyCorpus()
#     model = Word2Vec(sentences=sentences, min_count=0, size=10)
#     model.save("word2vec.npy")
#     return model


# get the word -> embedding index dictionary
def get_word_dict():
    train_path = data_root / "train.txt"
    word_dict_path = processed_data_root / "word_dict.json"
    reverse_word_dict_path = processed_data_root / "reverse_word_dict.json"
    word_dict = dict()
    reverse_word_dict = dict()
    count = 0
    if os.path.exists(word_dict_path):
        with open(word_dict_path) as f:
            word_dict = json.load(f)
        with open(reverse_word_dict_path) as f:
            reverse_word_dict = json.load(f)
            return word_dict, reverse_word_dict
    with open(train_path) as f:
        for line in f.readlines():
            for word in re.split(r"\s", line):
                word = word.lower()
                if word not in word_dict:
                    word_dict[word] = count
                    reverse_word_dict[count] = word
                    count = count + 1
    with open(word_dict_path, "w") as f:
        json.dump(word_dict, f)
    with open(reverse_word_dict_path, "w") as f:
        json.dump(reverse_word_dict, f)
    return word_dict, reverse_word_dict


# get_word_dict()
