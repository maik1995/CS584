import numpy as np
import tensorflow as tf
import re
from util import get_word_dict, get_test_path
from pathlib import Path
from keras.models import load_model

data_root = Path("a3-data/")
processed_data_root = Path("processed_data/")
model_path = "rnn_model"


# trans form sentence into list of embedding index
def transform_sentence(sentence, word_dict):
    words = re.split(r"\s", sentence)
    for i in range(len(words)):
        if words[i] not in word_dict:
            words[i] = '<unk>'
        words[i] = word_dict[words[i].lower()]
    return words


# the first layer is Embedding layer, output shape like (batch size, window size, 10)
# the second layer is LSTM layer, output shape like (batch size, window size, 128)
# the third layer is dense layer, output shape like (batch size, window size, dict_size)
# the last layer is softmax layer, output shape like (batch size, window size, dict_size)
def rnn_model(batch_size, window_size, units, dict_size):
    inputs = tf.keras.Input(shape=window_size, batch_size=batch_size, dtype="int32")
    # print(inputs.shape)
    embedding_layer_output = tf.keras.layers.Embedding(input_dim=dict_size, output_dim=10, input_length=window_size)(
        inputs)
    lstm_layer_seq_output = tf.keras.layers.LSTM(units=units, return_sequences=True,
                                                 dropout=1e-3)(embedding_layer_output)
    dense_layer_output = tf.keras.layers.Dense(units=dict_size)(lstm_layer_seq_output)
    softmax_output = tf.keras.layers.Softmax()(dense_layer_output)
    # print(lstm_layer_seq_output.shape)
    model = tf.keras.Model(inputs=inputs, outputs=softmax_output)
    return model


# generating batch of training x and y, x shape like (batch size, window size)
# y shape like (batch size, window size, dictionary size(the number of distinct word))
def train_data_generator(window_size, dict_size, batch_size, word_dict):
    train_path = data_root / "train.txt"
    while True:
        train_x = list()
        train_y = list()
        with open(train_path) as f:
            count = 0
            for line in f.readlines():
                words = transform_sentence(line, word_dict)
                if len(words) <= window_size:
                    fill = word_dict['']
                    temp = list()
                    for i in range(len(words), window_size + 1):
                        temp.append(fill)
                    temp.extend(words)
                    words = temp
                for i in range(0, len(words) - window_size):
                    train_x.append(words[i:i + window_size])
                    y_temp = list()
                    for j in range(i + 1, i + window_size + 1):
                        temp = np.zeros(dict_size)
                        temp[words[j]] = 1
                        y_temp.append(temp)
                    train_y.append(y_temp)
                    count += 1
                    if count % batch_size == 0:
                        array_x = np.array(train_x)
                        array_y = np.array(train_y)
                        train_x = list()
                        train_y = list()
                        yield array_x, array_y


units = 128


# train_model(20, 50, 1e-3), model_path is "rnn_model"
def train_model(window_size, batch_size, learning_rate=1e-3):
    word_dict, _ = get_word_dict()

    dict_size = len(word_dict)
    model = rnn_model(batch_size, window_size, units, dict_size)

    model.load_weights(model_path)
    model.summary()
    opt = tf.keras.optimizers.Adam(learning_rate=learning_rate)
    model.compile(optimizer=opt, loss="categorical_crossentropy")
    model.fit(train_data_generator(window_size, dict_size, batch_size, word_dict), steps_per_epoch=5000, epochs=10)
    model.save_weights(model_path)


# predict next word given sentence
def predict(sentence):
    word_dict, reverse_word_dict = get_word_dict()
    dict_size = len(word_dict)
    words = transform_sentence(sentence, word_dict)
    model = rnn_model(1, len(words), units, dict_size)
    words = [words]
    model.load_weights(model_path)
    softmax_result = model.predict(words)
    index = np.argmax(softmax_result, axis=2)
    return reverse_word_dict[str(index[0, -1])]


def calculate_perplexity_and_total_loss():
    word_dict, _ = get_word_dict()
    test_path = get_test_path()
    dict_size = len(word_dict)
    perplexity = 0
    total_loss = 0
    with open(test_path) as f:
        count = 0
        for line in f.readlines():
            count += 1
            words = transform_sentence(line, word_dict)
            given = words[0:-2]
            target = words[1:-1]
            y_true = np.zeros((len(target), dict_size))
            for i in range(0, len(target)):
                y_true[i, target[i]] = 1
            model = rnn_model(1, len(given), units, dict_size)
            given = [given]
            model.load_weights(model_path)
            softmax_result = model.predict(given)
            temp = 1
            for i in range(len(target)):
                temp *= 1 / softmax_result[0, i, target[i]]
            perplexity += pow(temp, 1 / len(target))
            loss = tf.losses.categorical_crossentropy(y_true, softmax_result)
            np.array(loss)
            total_loss += np.mean(loss)
        perplexity = perplexity / count
        total_loss = total_loss / count
    return perplexity, total_loss

# train_model(20, 50, 1e-3)
