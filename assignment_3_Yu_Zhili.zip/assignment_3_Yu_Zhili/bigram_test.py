import bigram_with_good_turing_smoothing
import bigram_with_Kneser_Ney_Smoothing
import raw_bigram
import util
import re


def perplexity_score(get_perplexity_score):
    test_path = util.get_test_path()
    perplexity_score = 0
    count = 0
    i = 0
    with open(test_path) as f:
        for line in f.readlines():
            count = count + 1
            temp = get_perplexity_score(line)
            perplexity_score = perplexity_score + temp
            i = i + 1
            if i % 10 == 0:
                print(temp)
                print(i / 5446)
    return perplexity_score / count


# the function used to get perplexity score
def get_perplexity_score():
    with open("bigram_perplexity.txt", "w") as f:
        good_perplexity = perplexity_score(bigram_with_good_turing_smoothing.get_perplexity_score)
        f.write("good turing perplexity:" + str(good_perplexity) + "\n")
        print("stage 1 finished")
        raw_perplexity = perplexity_score(raw_bigram.get_perplexity_score)
        f.write("raw bigram perplexity:" + str(raw_perplexity) + "\n")
        print("stage 2 finished")
        kneser_perplexity = perplexity_score(bigram_with_Kneser_Ney_Smoothing.get_perplexity_score)
        f.write("kneser Ney perplexity:" + str(kneser_perplexity) + "\n")
        print("stage 3 finished")


# use first 30 lines of input.txt to predict next word
def predict_next_word():
    with open("a3-data/input.txt") as f:
        with open("kneser_ney_generated_text.txt", 'w') as r_f:
            count = 0
            for line in f.readlines():
                slides = util.window_slide(line, 2)

                target = slides[-2]
                words = re.split(r'\s', target)
                predicted_word = bigram_with_Kneser_Ney_Smoothing.predict(words[0])
                print(predicted_word)
                r_f.write(line.replace("\n", "") + ":" + predicted_word + "\n")
                count = count + 1
                if count == 30:
                    break


get_perplexity_score()
predict_next_word()
