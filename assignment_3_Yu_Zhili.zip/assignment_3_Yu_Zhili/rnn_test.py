import math
import re

from rnn import predict, calculate_perplexity_and_total_loss


# the function used to get perplexity score and average of total loss
def get_perplexity_score_and_average_loss():
    perplexity, aveg_loss = calculate_perplexity_and_total_loss()
    e_loss = math.exp(aveg_loss)
    with open("rnn_perplexity_and_average_loss.txt", "w") as f:
        f.write("rnn perplexity:" + str(perplexity) + "\n")
        f.write("average loss:" + str(aveg_loss) + "\n")
        f.write("e to the power of average loss:" + str(e_loss) + "\n")
        print("stage 1 finished")


# use first 30 lines of input.txt to predict next word
def predict_next_word():
    with open("a3-data/input.txt") as f:
        with open("rnn_generated_text.txt", 'w') as r_f:
            count = 0
            for line in f.readlines():
                line = re.sub(r'[_]', '', line)
                predicted_word = predict(line[0:-2])
                r_f.write(line.replace("\n", "") + ":" + predicted_word + "\n")
                count = count + 1
                if count == 30:
                    break


get_perplexity_score_and_average_loss()
predict_next_word()
