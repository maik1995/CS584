import numpy as np
import heapq
from scipy.spatial import distance


def knn(word_vectors, index, word, k):
    x_i = index[word]
    x = word_vectors[x_i]
    n = word_vectors.shape[0]
    dis = np.zeros(shape=(n, 1))
    i = 0
    for word_vector in word_vectors:
        dis[i] += distance.cosine(x, word_vector)
        i += 1
    dis = dis.flatten()
    return dis.argsort()[:k+1]


