# %% md

# 1. Process data

# %%

import os
import jsonlines

import numpy as np
#os.environ["CUDA_VISIBLE_DEVICES"]="-1"
import tensorflow as tf
from tensorflow.python.client import device_lib

gpus = tf.config.list_physical_devices('GPU')
print(gpus)
if gpus:
    tf.config.experimental.set_memory_growth(gpus[0], True)

import tensorflow_hub as hub

from official.nlp import bert

import official.nlp.bert.tokenization


# %% md

## 1.1 Load data

# %%


def read_recam(path):
    sentences_a = list()
    sentences_q = list()
    correct_words = list()
    all_options = list()
    with open(path, mode='r', encoding="utf8") as f:
        reader = jsonlines.Reader(f)
        for instance in reader:
            article = instance.get("article")
            question = instance.get("question")
            question = question.replace("@placeholder", "[MASK]")
            options = [instance.get("option_0"),
                       instance.get("option_1"),
                       instance.get("option_2"),
                       instance.get("option_3"),
                       instance.get("option_4")]
            correct_word = options[instance.get("label")].lower()
            sentences_a.append(article)
            sentences_q.append(question)
            correct_words.append(correct_word)
            all_options.append(options)

    return sentences_a, sentences_q, correct_words, all_options


root_path = os.path.join(os.getcwd(), "data/train_data/")
task1_train_path = root_path + "Task_1_train.jsonl"
task1_sentences_a, task1_sentences_q, task1_labels, task1_options = read_recam(task1_train_path)
task2_train_path = root_path + "Task_2_train.jsonl"
task2_sentences_a, task2_sentences_q, task2_labels, task2_options = read_recam(task2_train_path)

task1_train_sentences_a = task1_sentences_a[0:int(0.8 * len(task1_sentences_a))]
task1_train_sentences_q = task1_sentences_q[0:int(0.8 * len(task1_sentences_q))]
task1_test_sentences_a = task1_sentences_a[int(0.8 * len(task1_sentences_a)):len(task1_sentences_a)]
task1_test_sentences_q = task1_sentences_q[int(0.8 * len(task1_sentences_q)):len(task1_sentences_q)]

task2_train_sentences_a = task2_sentences_a[0:int(0.8 * len(task2_sentences_a))]
task2_train_sentences_q = task2_sentences_q[0:int(0.8 * len(task2_sentences_q))]
task2_test_sentences_a = task2_sentences_a[int(0.8 * len(task2_sentences_a)):len(task2_sentences_a)]
task2_test_sentences_q = task2_sentences_q[int(0.8 * len(task2_sentences_q)):len(task2_sentences_q)]

task1_train_labels = task1_labels[0:int(0.8 * len(task1_labels))]
task1_test_labels = task1_labels[int(0.8 * len(task1_labels)):len(task1_labels)]

task2_train_labels = task2_labels[0:int(0.8 * len(task2_labels))]
task2_test_labels = task2_labels[int(0.8 * len(task2_labels)):len(task2_labels)]

task1_test_options = task1_options[int(0.8 * len(task1_options)):len(task1_options)]
task2_test_options = task2_options[int(0.8 * len(task2_options)):len(task2_options)]

# %% md

## 1.2 Tokenlize data

# %%

# load tokenizer
bert_root = "bert_model/"
tokenizer = bert.tokenization.FullTokenizer(
    vocab_file=os.path.join(bert_root, "vocab.txt"),
    do_lower_case=True)


# %% md

### tokenize the sentences

# %%

def encode_sentence(s, _tokenizer):
    tokens = list(_tokenizer.tokenize(s))
    tokens.append('[SEP]')
    return _tokenizer.convert_tokens_to_ids(tokens)


def bert_encode(sentences_a, sentences_q, _tokenizer=tokenizer):
    sentence1 = [
        encode_sentence(s, _tokenizer)
        for s in np.array(sentences_a)]
    sentence2 = [
        encode_sentence(s, _tokenizer)
        for s in np.array(sentences_q)]
    # reduce the length of sentence
    for i in range((len(sentence1) - 1)):
        if len(sentence1[i]) + len(sentence2[i]) >= 512:
            r = 512 - len(sentence2[i]) - 1
            del sentence1[i][0:len(sentence1[i]) - r]

    sentence1 = tf.ragged.constant(sentence1)
    sentence2 = tf.ragged.constant(sentence2)

    cls = [_tokenizer.convert_tokens_to_ids(['[CLS]'])] * sentence1.shape[0]
    input_word_ids = tf.concat([cls, sentence1, sentence2], axis=-1)

    input_mask = tf.ones_like(input_word_ids).to_tensor()

    type_cls = tf.zeros_like(cls)
    type_s1 = tf.zeros_like(sentence1)
    type_s2 = tf.ones_like(sentence2)
    input_type_ids = tf.concat(
        [type_cls, type_s1, type_s2], axis=-1).to_tensor()

    inputs = {
        'input_word_ids': input_word_ids.to_tensor(),
        'input_mask': input_mask,
        'input_type_ids': input_type_ids}

    return inputs


task1_train_x = bert_encode(task1_train_sentences_a, task1_train_sentences_q)
task1_test_x = bert_encode(task1_test_sentences_a, task1_test_sentences_q)

task2_train_x = bert_encode(task2_train_sentences_a, task2_train_sentences_q)
task2_test_x = bert_encode(task2_test_sentences_a, task2_test_sentences_q)


# %% md

### transfer correct word to one hot embedding base on tokenizer vocabulary

# %%

def encode_word(w):
    tokens = list(tokenizer.tokenize(w))
    w_index = tokenizer.convert_tokens_to_ids(tokens)
    temp = np.zeros(shape=(len(tokenizer.vocab)))
    temp[w_index] = 1
    return temp


task1_train_y = [encode_word(w) for w in task1_train_labels]
task1_test_y = [encode_word(w) for w in task1_test_labels]

task2_train_y = [encode_word(w) for w in task2_train_labels]
task2_test_y = [encode_word(w) for w in task2_test_labels]

task1_test_options = [[tokenizer.convert_tokens_to_ids(list(tokenizer.tokenize(w))) for w in options] for options in
                      task1_test_options]
task2_test_options = [[tokenizer.convert_tokens_to_ids(list(tokenizer.tokenize(w))) for w in options] for options in
                      task2_test_options]

# %%

task1_train_y = np.array(task1_train_y)
task1_test_y = np.array(task1_test_y)
task2_train_y = np.array(task2_train_y)
task2_test_y = np.array(task2_test_y)

# %% md

# 2. Build Model and train

# %% md

## 2.1 Define BERT+NN Model


# %%


os.environ["TFHUB_CACHE_DIR"] = "/tmp/model2"

bert_encoder = hub.KerasLayer(
    "https://tfhub.dev/tensorflow/small_bert/bert_en_uncased_L-8_H-256_A-4/1",
    trainable=False)


# %%

def Bert_NN_Module(seq_length, batch_size, bert_encoder, num_labels, model_name):
    input_word_ids = tf.keras.layers.Input(
        shape=(seq_length,),  dtype=tf.int32, name='input_word_ids')
    input_mask = tf.keras.layers.Input(
        shape=(seq_length,),  dtype=tf.int32, name='input_mask')
    input_type_ids = tf.keras.layers.Input(
        shape=(seq_length,),  dtype=tf.int32, name='input_type_ids')
    encoder_input = dict(
        input_mask=input_mask,
        input_type_ids=input_type_ids,
        input_word_ids=input_word_ids
    )
    outputs = bert_encoder(encoder_input)
    output = tf.keras.layers.LSTM(
            512,
            # batch_input_shape=(batch_size, seq_length, 256),
            return_sequences=True
    )(outputs["sequence_output"])
    # output = tf.keras.layers.BatchNormalization()(output)
    output = tf.keras.layers.LSTM(512)(output)
    # output = tf.keras.layers.BatchNormalization()(output)

    output = tf.keras.layers.Dense(
        num_labels, name='output', activation="softmax")(output)

    return tf.keras.Model(inputs={
        'input_word_ids': input_word_ids,
        'input_mask': input_mask,
        'input_type_ids': input_type_ids
    }, outputs=output, name=model_name)


# %% md

## 2.2 Train the model

# %%

batch_size = 32

task1_model = Bert_NN_Module(512, batch_size, bert_encoder, 30522, "Task1_Model")

# %%

task1_model.summary()

# %%

task2_model = Bert_NN_Module(512, batch_size, bert_encoder, 30522, "Task2_Model")

# %%

task2_model.summary()

# %%

lr = 1e-3
epochs = 30

# %%

checkpoint_filepath = './task1_prediction_model/'
model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(
    filepath=checkpoint_filepath,
    save_weights_only=True,
    monitor='accuracy',
    mode='max',
    save_best_only=True)
task1_model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
                    loss="categorical_crossentropy",
                    metrics=[tf.keras.metrics.Accuracy()])
# task1_model.load_weights(checkpoint_filepath)
task1_model.fit(x=task1_train_x,
                y=task1_train_y,
                epochs=epochs,
                verbose=1,
                batch_size=batch_size,
                callbacks=[model_checkpoint_callback])

# %%

checkpoint_filepath = './task2_prediction_model/'
model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(
    filepath=checkpoint_filepath,
    save_weights_only=True,
    monitor='accuracy',
    mode='max',
    save_best_only=True)
task2_model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
                    loss="categorical_crossentropy",
                    metrics=[tf.keras.metrics.Accuracy()])
# task2_model.load_weights(checkpoint_filepath)
task2_model.fit(x=task2_train_x,
                y=task2_train_y,
                epochs=epochs,
                verbose=1,
                batch_size=batch_size,
                callbacks=[model_checkpoint_callback])


# %% md

# 3. Test

# %% md

## 3.1 Test task 1

# %%

# predict base on finding the
def predict(model_output, options):
    result = np.zeros(shape=(options.shape[0]))
    for i in range(options.shape[0]):
        temp = model_output[i, options[i]]
        index = np.argmax(temp)
        result[i] = options[i, index]
    return result


def calculate_acc(model, x, y, options):
    options = np.array(options)
    model_output = model.predict(x)
    prediction = predict(model_output, options)
    y = np.argmax(y, axis=1)
    return np.sum(np.equal(prediction, y)) / options.shape[0]


# %%

task1_model = Bert_NN_Module(512, 1, bert_encoder, 30522, "Task1_Model")
checkpoint_filepath = './task1_prediction_model/'
task1_model.load_weights(checkpoint_filepath)
task1_acc = calculate_acc(task1_model, task1_test_x, task1_test_y, task1_test_options)
print("accuracy of task1 is:")
print(task1_acc)

# %%

task2_model = Bert_NN_Module(512, 1, bert_encoder, 30522, "Task1_Model")
checkpoint_filepath = './task2_prediction_model/'
task2_model.load_weights(checkpoint_filepath)
task2_acc = calculate_acc(task2_model, task2_test_x, task2_test_y, task2_test_options)
print("accuracy of task1 is:")
print(task2_acc)
