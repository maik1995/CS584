import os
import jsonlines
from attention import Attention
import numpy as np
# os.environ["CUDA_VISIBLE_DEVICES"]="-1"
import tensorflow as tf
gpus= tf.config.list_physical_devices('GPU')
print(gpus)
if gpus:
    tf.config.experimental.set_memory_growth(gpus[0], True)

import tensorflow_hub as hub

from official.nlp import bert

import official.nlp.bert.tokenization


def read_recam(path):
    sentences_a = list()
    sentences_q = list()
    correct_words = list()
    all_options = list()
    with open(path, mode='r', encoding="utf8") as f:
        reader = jsonlines.Reader(f)
        for instance in reader:
            article = instance.get("article")
            question = instance.get("question")
            question = question.replace("@placeholder", "[MASK]")
            options = [instance.get("option_0"),
                       instance.get("option_1"),
                       instance.get("option_2"),
                       instance.get("option_3"),
                       instance.get("option_4")]
            correct_word = options[instance.get("label")].lower()
            sentences_a.append(article)
            sentences_q.append(question)
            correct_words.append(correct_word)
            all_options.append(options)

    return sentences_a, sentences_q, correct_words, all_options


root_path = "data/train_data/"
task1_train_path = root_path + "Task_1_train.jsonl"
task1_sentences_a, task1_sentences_q, task1_labels, task1_options = read_recam(task1_train_path)
task2_train_path = root_path + "Task_2_train.jsonl"
task2_sentences_a, task2_sentences_q, task2_labels, task2_options = read_recam(task2_train_path)

task1_train_sentences_a = task1_sentences_a[0:int(0.8 * len(task1_sentences_a))]
task1_train_sentences_q = task1_sentences_q[0:int(0.8 * len(task1_sentences_q))]
task1_test_sentences_a = task1_sentences_a[int(0.8 * len(task1_sentences_a)):len(task1_sentences_a)]
task1_test_sentences_q = task1_sentences_q[int(0.8 * len(task1_sentences_q)):len(task1_sentences_q)]

task2_train_sentences_a = task2_sentences_a[0:int(0.8 * len(task2_sentences_a))]
task2_train_sentences_q = task2_sentences_q[0:int(0.8 * len(task2_sentences_q))]
task2_test_sentences_a = task2_sentences_a[int(0.8 * len(task2_sentences_a)):len(task2_sentences_a)]
task2_test_sentences_q = task2_sentences_q[int(0.8 * len(task2_sentences_q)):len(task2_sentences_q)]

task1_train_labels = task1_labels[0:int(0.8 * len(task1_labels))]
task1_test_labels = task1_labels[int(0.8 * len(task1_labels)):len(task1_labels)]

task2_train_labels = task2_labels[0:int(0.8 * len(task2_labels))]
task2_test_labels = task2_labels[int(0.8 * len(task2_labels)):len(task2_labels)]

task1_train_options = task1_options[0:int(0.8 * len(task1_options))]
task1_test_options = task1_options[int(0.8 * len(task1_options)):len(task1_options)]

task2_train_options = task1_options[0:int(0.8 * len(task2_options))]
task2_test_options = task2_options[int(0.8 * len(task2_options)):len(task2_options)]

import re

#处理label
task1_train_labels_num = []
for t in range(len(task1_train_options)):
        task1_train_labels_num.append(task1_train_options[t].index(task1_train_labels[t]))
#print(task1_train_labels_num)
a = np.array(task1_train_labels_num)


task1_train_labels_num = np.zeros((a.size, a.max()+1))
task1_train_labels_num[np.arange(a.size), a] = 1


task1_train_options_after = []
for i in task1_train_options:
    task1_train_options_after.append(i[0]+','+i[1]+','+i[2]+','+i[3]+','+i[4]+',')

training_set = []
for i in range(len(task1_train_options)):
    training_set.append(task1_train_sentences_a[i] + task1_train_sentences_q[i] + task1_train_options_after[i])


## Iterate over the data to preprocess by removing stopwords
lines_without_stopwords=[]
for line in training_set:
    line = line.lower()
    line_by_words = re.findall(r'(?:\w+)', line, flags = re.UNICODE) # remove punctuation ans split
    new_line=[]

    for word in line_by_words:
        new_line.append(word)
    lines_without_stopwords.append(new_line)
texts = lines_without_stopwords


from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences

MAX_NUM_WORDS = 40000
MAX_SEQUENCE_LENGTH = 1000
tokenizer = Tokenizer(num_words=MAX_NUM_WORDS)
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
print('Found %s sequences.' % len(sequences))
word_index = tokenizer.word_index
print('Found %s unique tokens.' % len(word_index))
data = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH)
print(data.shape)



from keras.layers import Embedding
from keras.initializers import Constant

embeddings_index = {}
f = open('glove.840B.300d.txt')
for line in f:
    values = line.split(' ')
    word = values[0] ## The first entry is the word
    coefs = np.asarray(values[1:], dtype='float32') ## These are the vecotrs representing the embedding for the word
    embeddings_index[word] = coefs
f.close()

print('GloVe data loaded')



## EMBEDDING_DIM =  ## seems to need to match the embeddings_index dimension
EMBEDDING_DIM = embeddings_index.get('a').shape[0]
num_words = min(MAX_NUM_WORDS, len(word_index)) + 1
embedding_matrix = np.zeros((num_words, EMBEDDING_DIM))
for word, i in word_index.items():
    if i > MAX_NUM_WORDS:
        continue
    embedding_vector = embeddings_index.get(word) ## This references the loaded embeddings dictionary
    if embedding_vector is not None:
        # words not found in embedding index will be all-zeros.
        embedding_matrix[i] = embedding_vector

# load pre-trained word embeddings into an Embedding layer
# note that we set trainable = False so as to keep the embeddings fixed
embedding_layer = Embedding(num_words,
                            EMBEDDING_DIM,
                            embeddings_initializer=Constant(embedding_matrix),
                            input_length=MAX_SEQUENCE_LENGTH,
                            trainable=False)
from keras.models import Sequential
from keras.layers import Dense, Flatten, LSTM, \
    Conv1D, MaxPooling1D, Dropout, Activation, Embedding, BatchNormalization, Conv2D
import keras.layers as layers
model = Sequential()

model.add(Embedding(num_words, 300, input_length=1000, weights= [embedding_matrix], trainable=False))
model.add(LSTM(
    512,
    # batch_input_shape=(batch_size, seq_length, 256),
    return_sequences=True
))
model.add(Dropout(0.2))

model.add(Attention())

model.add(Dense(32, activation='softmax'))
model.add(Dense(5, activation='softmax'))

model.add(BatchNormalization())
model.summary()

# %%

lr = 1e-5
epochs = 60
batch_size = 128
# %%

checkpoint_filepath = './task1_prediction_model/'
model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(
    filepath=checkpoint_filepath,
    save_weights_only=True,
    monitor='accuracy',
    mode='max',
    save_best_only=True)
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
                    loss="categorical_crossentropy",
                    metrics=[tf.keras.metrics.Accuracy()])
# task1_model.load_weights(checkpoint_filepath)
model.fit(x=data,
                y=task1_train_labels_num,
                epochs=epochs,
                verbose=1,
                batch_size=batch_size,
                callbacks=[model_checkpoint_callback])



def predict(model_output, options):
    result = np.zeros(shape=(options.shape[0]))
    for i in range(options.shape[0]):
        temp = model_output[i, options[i]]
        index = np.argmax(temp)
        result[i] = options[i, index]
    return result


def calculate_acc(model, x, y, options):
    options = np.array(options)
    model_output = model.predict(x)
    prediction = predict(model_output, options)
    y = np.argmax(y, axis=1)
    return np.sum(np.equal(prediction, y)) / options.shape[0]


# %%

checkpoint_filepath = './task1_prediction_model/'
model.load_weights(checkpoint_filepath)
task1_acc = calculate_acc(model, task1_test_x, task1_test_y, task1_test_options)
print("accuracy of task1 is:")
print(task1_acc)










